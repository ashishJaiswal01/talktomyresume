import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home(){
  const [origin, setOrigin] = useState('');
  const navigate = useNavigate();

  const search = (e) => {
    e.preventDefault();
    if (!origin) return alert('Please enter origin city');
    navigate('/results', { state: { origin } });
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-4xl font-bold mb-4">Find the cheapest place to travel from your city</h1>
      <form onSubmit={search} className="space-y-4">
        <input value={origin} onChange={e=>setOrigin(e.target.value)} placeholder="From (e.g., Mumbai)" className="w-full p-3 border rounded" />
        <div className="flex gap-2">
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Search Cheapest Destinations</button>
          <button type="button" onClick={()=>{setOrigin('Mumbai')}} className="px-4 py-2 border rounded">Example: Mumbai</button>
        </div>
      </form>
    </div>
  )
}
