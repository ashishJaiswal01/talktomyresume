import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Results(){
  const loc = useLocation();
  const navigate = useNavigate();
  const origin = loc.state?.origin || '';
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  useEffect(()=>{
    if (!origin) { navigate('/'); return; }
    setLoading(true);
    axios.post(`${import.meta.env.VITE_API_BASE || '/api'}/search-cheapest`, { origin })
      .then(r => setData(r.data))
      .catch(err => console.error(err))
      .finally(()=> setLoading(false));
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-semibold mb-4">Cheapest destinations from {origin}</h2>
      {loading && <div>Loading...</div>}
      {!loading && data && (
        <div className="grid gap-4">
          {data.candidates.map(c => (
            <div key={c.destination} className="p-4 border rounded flex justify-between items-center">
              <div>
                <div className="text-lg font-bold">{c.destination}</div>
                <div className="text-sm text-gray-600">{c.airline} • {c.duration} • Best month: {c.bestMonth}</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-semibold">{c.currency} {c.price}</div>
                <button onClick={()=> navigate('/details', { state: { origin, candidate: c } })} className="mt-2 px-3 py-1 bg-green-600 text-white rounded">View</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
