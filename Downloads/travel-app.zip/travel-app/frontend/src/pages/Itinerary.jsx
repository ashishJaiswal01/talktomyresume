import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

export default function Itinerary(){
  const loc = useLocation();
  const { origin, destination } = loc.state || {};
  const [loading, setLoading] = useState(false);
  const [itinerary, setItinerary] = useState(null);
  const [days, setDays] = useState(3);
  const [stars, setStars] = useState(3);

  const generate = async () => {
    setLoading(true);
    try {
      const res = await axios.post(`${import.meta.env.VITE_API_BASE || '/api'}/itinerary`, { origin, destination, days, hotelStars: stars });
      setItinerary(res.data.itinerary);
    } catch(e) {
      console.error(e);
      alert('Error generating itinerary');
    } finally {
      setLoading(false);
    }
  }

  if (!destination) return <div className="p-6">No destination data</div>;

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h2 className="text-2xl font-bold">Itinerary for {destination}</h2>
      <div className="mt-4 space-y-2">
        <label>
          Days:
          <input type="number" value={days} onChange={e => setDays(Number(e.target.value))} className="ml-2 p-1 border" />
        </label>
        <label>
          Hotel stars:
          <select value={stars} onChange={e => setStars(Number(e.target.value))} className="ml-2 p-1 border">
            {[1,2,3,4,5].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
        <div>
          <button onClick={generate} className="bg-green-600 text-white px-4 py-2 rounded">{loading ? 'Generating...' : 'Generate Itinerary'}</button>
        </div>
      </div>

      {itinerary && (
        <div className="mt-6 p-4 border rounded bg-white">
          <h3 className="font-semibold">{itinerary.summary}</h3>
          <div className="mt-3">
            {itinerary.days.map(d => (
              <div key={d.day} className="mb-2">
                <div className="font-semibold">Day {d.day}</div>
                <div>{d.plan}</div>
              </div>
            ))}
            <div className="mt-2 font-bold">Estimated total: {itinerary.estimatedTotal}</div>
          </div>
        </div>
      )}
    </div>
  )
}
