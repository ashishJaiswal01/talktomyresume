import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function Details(){
  const loc = useLocation();
  const navigate = useNavigate();
  const { origin, candidate } = loc.state || {};
  if (!candidate) return <div className="p-6">No destination selected</div>;

  const buildItinerary = () => {
    navigate('/itinerary', { state: { origin, destination: candidate.destination }});
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">{candidate.destination}</h1>
      <p className="text-gray-600">Cheapest fare: {candidate.currency} {candidate.price} via {candidate.airline}</p>
      <p className="mt-4">Duration: {candidate.duration} • Best month: {candidate.bestMonth}</p>

      <div className="mt-6 space-y-2">
        <button onClick={buildItinerary} className="bg-blue-600 text-white px-4 py-2 rounded">Build Itinerary</button>
      </div>
    </div>
  )
}
