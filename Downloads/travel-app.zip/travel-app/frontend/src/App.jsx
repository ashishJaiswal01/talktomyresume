import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Results from './pages/Results';
import Details from './pages/Details';
import Itinerary from './pages/Itinerary';

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/results" element={<Results/>} />
        <Route path="/details" element={<Details/>} />
        <Route path="/itinerary" element={<Itinerary/>} />
      </Routes>
    </div>
  )
}
