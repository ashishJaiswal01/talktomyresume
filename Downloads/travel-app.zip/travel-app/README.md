# Travel App (Cheapest Destination Finder + Itinerary Builder)

## Overview
This repo is a full-stack travel app: React frontend + Node.js Express backend. Backend uses travel API wrappers (mocked) and an LLM integration stub for itinerary generation and summarization. The app is ready to deploy to Firebase Hosting + Functions.

## Features
- Input origin (city) and get cheapest destination results
- View destination details (price, airline, duration, best month)
- Generate a day-by-day itinerary (with hotel preference & duration)
- Mocked travel API responses safe for local dev
- LLM integration stub (OpenAI) — works with and without API key

## Local setup

### Prereqs
- Node.js 18+ (or recommended LTS)
- npm or pnpm
- Firebase CLI (if you will deploy)

### Backend
```bash
cd backend
cp .env.example .env
# fill .env with keys if you have them (optional)
npm install
npm run dev   # starts server at http://localhost:8080
```

### Frontend
```bash
cd frontend
npm install
npm run dev   # starts dev server (Vite) at http://localhost:5173
# or build
npm run build
npm run preview
```

By default frontend requests backend at `/api/*` — in development you can use a simple proxy in Vite or set `VITE_API_BASE` env.

### Fullstack Local
- Start backend at :8080
- Start frontend at :5173
- When calling `/api/...`, point to `http://localhost:8080` (set VITE_API_BASE)

## Deploy to Firebase Hosting + Functions

1. Install Firebase CLI and login:
```bash
npm install -g firebase-tools
firebase login
```

2. Initialize Firebase in the repo (one time):
```bash
firebase init
# Enable: Hosting and Functions
# Set frontend dist folder to "frontend/dist" and functions source to "backend"
```

3. Build frontend and deploy:
```bash
cd frontend
npm run build
cd ..
firebase deploy --only hosting,functions
```

## API endpoints (examples)

### POST /api/search-cheapest
**Request**
```json
{ "origin": "Mumbai" }
```
**Response**
```json
{
  "origin": "Mumbai",
  "candidates": [
    {"destination":"Kathmandu, Nepal", "price":120, "currency":"USD", "airline":"Nepal Airlines", "duration":"3h", "bestMonth":"Mar", "trend":"down"},
    ...
  ],
  "summary": { "text": "Top cheapest destinations ..." }
}
```

### POST /api/itinerary
**Request**
```json
{ "origin":"Mumbai", "destination":"Bali, Indonesia", "days":5, "hotelStars":3, "budgetProfile":"budget" }
```
**Response**
```json
{ "itinerary": { "summary":"...", "days":[{ "day":1, "plan":"..." }], "estimatedTotal": ... } }
```

## Next steps (integrate real providers)
- Replace `travelApi` mocks with Skyscanner / Amadeus / Google Flights APIs (they need API keys & account).
- Harden LLM usage: use function calling, provide source citations, validate hallucination.
- Add authentication, user profiles, saved itineraries, payment links/redirects.

## License
MIT
