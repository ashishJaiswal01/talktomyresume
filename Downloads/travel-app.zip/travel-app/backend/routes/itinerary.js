const express = require('express');
const router = express.Router();
const llm = require('../services/llm');
const travelApi = require('../services/travelApi');

router.post('/', async (req, res) => {
  try {
    const { origin, destination, days = 3, hotelStars = 3, budgetProfile = 'standard' } = req.body;
    if (!origin || !destination) return res.status(400).json({ error: 'origin & destination required' });

    const flights = await travelApi.searchFlights(origin, destination, { budgetProfile });
    const hotels = await travelApi.searchHotels(destination, hotelStars, { budgetProfile });

    const itinerary = await llm.generateItinerary({ origin, destination, days, flights, hotels, hotelStars, budgetProfile });

    res.json({ origin, destination, days, flights, hotels, itinerary });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error', details: err.message });
  }
});

module.exports = router;
