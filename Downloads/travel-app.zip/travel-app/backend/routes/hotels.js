const express = require('express');
const router = express.Router();
const travelApi = require('../services/travelApi');

router.get('/', async (req, res) => {
  try {
    const { destination, stars = 3 } = req.query;
    if (!destination) return res.status(400).json({ error: 'destination required' });
    const hotels = await travelApi.searchHotels(destination, Number(stars));
    res.json({ destination, hotels });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error', details: err.message });
  }
});

module.exports = router;
