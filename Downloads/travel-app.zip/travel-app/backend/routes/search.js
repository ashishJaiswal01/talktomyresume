const express = require('express');
const router = express.Router();
const travelApi = require('../services/travelApi');
const llm = require('../services/llm');

router.post('/', async (req, res) => {
  try {
    const { origin, filters } = req.body;
    if (!origin) return res.status(400).json({ error: 'origin required' });

    const candidates = await travelApi.searchCheapestFrom(origin, filters);
    const summary = await llm.summarizeCheapestDestinations(origin, candidates);

    res.json({ origin, candidates, summary });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error', details: err.message });
  }
});

module.exports = router;
