const sampleDestinations = [
  { destination: "Bali, Indonesia", price: 220, currency: "USD", airline: "AirAsia", duration: "8h", bestMonth: "May", trend: "down" },
  { destination: "Bangkok, Thailand", price: 180, currency: "USD", airline: "Thai Airways", duration: "6h", bestMonth: "June", trend: "stable" },
  { destination: "Dubai, UAE", price: 300, currency: "USD", airline: "Emirates", duration: "4h 30m", bestMonth: "Nov", trend: "up" },
  { destination: "Singapore", price: 260, currency: "USD", airline: "Singapore Airlines", duration: "5h", bestMonth: "Feb", trend: "stable" },
  { destination: "Kathmandu, Nepal", price: 120, currency: "USD", airline: "Nepal Airlines", duration: "3h", bestMonth: "Mar", trend: "down" }
];

function getCheapestDestinations(origin, filters = {}) {
  return sampleDestinations.sort((a,b) => a.price - b.price);
}

function getFlights(origin, destination, opts = {}) {
  return [
    { fare: 180, airline: "MockAir", duration: "6h", depart: "2026-06-10T07:30", arrive: "2026-06-10T13:30", stops: 0 },
    { fare: 140, airline: "BudgetAir", duration: "9h", depart: "2026-06-10T22:00", arrive: "2026-06-11T07:00", stops: 1 }
  ];
}

function getHotels(destination, stars = 3, opts = {}) {
  return [
    { name: `${destination} Grand`, stars, pricePerNight: stars >= 4 ? 140 : 45, rating: 4.3, distanceKm: 2.5 },
    { name: `${destination} Budget Inn`, stars: Math.max(1, stars-2), pricePerNight: 25, rating: 3.8, distanceKm: 5.1 }
  ];
}

function getActivities(destination, opts = {}) {
  return [
    { title: "City Walking Tour", price: 30, time: "3h" },
    { title: "Museum Entry + Guide", price: 20, time: "2h" }
  ];
}

function generateMockItinerary({origin, destination, days, hotelStars, budgetProfile}) {
  const daysPlan = [];
  for (let i=1;i<=days;i++){
    daysPlan.push({ day: i, plan: `Explore top sights in ${destination} on day ${i}. Suggested activity: City Walking Tour.`});
  }
  return { summary: `A ${days}-day ${budgetProfile} trip to ${destination}`, days: daysPlan, estimatedTotal: 300 + days * (hotelStars*30) };
}

module.exports = {
  getCheapestDestinations,
  getFlights,
  getHotels,
  getActivities,
  generateMockItinerary
};
