require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const searchRouter = require('./routes/search');
const itineraryRouter = require('./routes/itinerary');
const hotelsRouter = require('./routes/hotels');
const activitiesRouter = require('./routes/activities');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/search-cheapest', searchRouter);
app.use('/api/itinerary', itineraryRouter);
app.use('/api/hotels', hotelsRouter);
app.use('/api/activities', activitiesRouter);

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// Export app for Firebase Functions
module.exports = app;

// Local run when not in functions
if (require.main === module) {
  const port = process.env.PORT || 8080;
  app.listen(port, () => {
    console.log(`Backend listening at http://localhost:${port}`);
  });
}
