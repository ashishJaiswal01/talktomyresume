const mock = require('../utils/mockData');

async function searchCheapestFrom(origin, filters = {}) {
  return mock.getCheapestDestinations(origin, filters);
}

async function searchFlights(origin, destination, opts = {}) {
  return mock.getFlights(origin, destination, opts);
}

async function searchHotels(destination, stars = 3, opts = {}) {
  return mock.getHotels(destination, stars, opts);
}

async function searchActivities(destination, opts = {}) {
  return mock.getActivities(destination, opts);
}

module.exports = {
  searchCheapestFrom,
  searchFlights,
  searchHotels,
  searchActivities
};
