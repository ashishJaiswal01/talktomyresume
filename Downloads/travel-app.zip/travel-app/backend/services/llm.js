const OpenAI = require('openai');
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const mock = require('../utils/mockData');

async function summarizeCheapestDestinations(origin, candidates) {
  if (!openai) {
    return {
      text: `Top cheapest destinations from ${origin} are ${candidates.slice(0,5).map(c=>c.destination).join(', ')}.`,
      top: candidates[0] || null
    };
  }

  const prompt = `You are a travel assistant. Summarize these destinations for origin=${origin} and highlight best travel month and price trend. Data: ${JSON.stringify(candidates.slice(0,10))}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 300
  });

  return { text: response.choices[0].message.content };
}

async function generateItinerary({ origin, destination, days, flights, hotels, hotelStars, budgetProfile }) {
  if (!openai) {
    return mock.generateMockItinerary({ origin, destination, days, hotelStars, budgetProfile });
  }

  const prompt = `Create a ${days}-day itinerary for a trip from ${origin} to ${destination} with ${hotelStars}-star hotels. Flights: ${JSON.stringify(flights)} Hotels: ${JSON.stringify(hotels)} Budget profile: ${budgetProfile}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 800
  });
  return { text: response.choices[0].message.content };
}

module.exports = {
  summarizeCheapestDestinations,
  generateItinerary
};
